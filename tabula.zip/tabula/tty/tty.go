// Package tty implements a teletype interface for Taleä.
package tty

import "os"

type Tty struct {
	File string;
	char int;
}

func (t *Tty) Write() error {
	f, err := os.OpenFile(t.File, os.O_APPEND | os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = f.Write([]byte{byte(t.char)})
	if err != nil {
		return err
	}

	t.char = 0
	return nil
}

func (t *Tty) Char(c byte) {
	t.char = int(c)
}