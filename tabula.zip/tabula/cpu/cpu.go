// Package cpu implements the processor for Taleä, constants
// to provide configuration and utility functions and routines
// to manage memory and registers.
package cpu

import (
	"fmt"
	"time"
)

const (

	// Miscellaneous Architecture constants
	Hz                     = 1
	ClockSpeed             = 1000000 * Hz
	ClockSpeedMilliseconds = 1000 * (1.0 / ClockSpeed)

	// This does not include Ip
	GeneralPurposeRegCount = 10
	SpecialPurposeRegCount = 5

	// Memory
	MemorySize = MaxMemorySize * Byte
)

// A Cpu represents a processor, with its registers and memory.
type Cpu struct {
	RegisterFile [RegisterFileSize]uint8
	Memory       [MemorySize]uint8
}

func (c *Cpu) Cycle() {
	err := c.Execute(c.Fetch())

	if err != nil {
		panic(err)
	}
}

func (c *Cpu) Clock(f func(), speed int) {

	ticker := time.NewTicker(time.Duration(speed) * time.Millisecond)
	done := make(chan bool)

	go func() {
		for {
			select {
			case <-done:
				return
			case t := <-ticker.C:
				f()
				fmt.Println("Tick at", t)
			}
		}
	}()
}
