package cpu

const (
	
	// Bitsizes

	Bit				= 1
	ByteSize		= 8 * Bit
	WordSize		= 16 * Bit

	DataBusSize		= 8 * Bit
	AddressBusSize 	= 24 * Bit
)

const (

	// Sizes (in Bytes)

	Byte 					= 1
	Word 					= 2 * Byte

	StatusRegSize			= Byte
	MemoryBankRegSize		= Byte
	ChapterXRegSize			= Byte
	PaginaXRegSize 			= Byte
	LitteraXRegSize			= Byte

	StackPointerSize		= Word
	FramePointerSize		= Word
	GeneralPurposeRegSize 	= Word

	InstructionPointerSize 	= 3 * Byte


	RegisterFileSize 		= (
		(GeneralPurposeRegCount * GeneralPurposeRegSize) 			+
		StackPointerSize 	+ FramePointerSize 	+
		StatusRegSize 		+ MemoryBankRegSize +
		ChapterXRegSize 	+ PaginaXRegSize 	+ LitteraXRegSize 	+
		InstructionPointerSize)

	// This is only max-memory size. 
	//TODO: Control over some constants, such as memory size, clock speed and the like
	MaxMemorySize = 1 << AddressBusSize * Byte
)

const (

	// Special Purpose Register Indexes on RegFile
	Ss   = iota * StatusRegSize
	Mb   = iota * MemoryBankRegSize
	Cx   = iota * ChapterXRegSize
	Px   = iota * PaginaXRegSize
	Lx   = iota * LitteraXRegSize
)

const (

	// Stack Registers Indexes on RegFile
	Sp   = iota + SpecialPurposeRegCount
	Fp   = (iota * FramePointerSize) + SpecialPurposeRegCount
	
	// General Purpose Register Indexes on RegFile
	Acc  = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	Bcc  = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R0   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R1   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R2   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R3   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R4   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R5   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R6   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	R7   = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
	
	//Instruction Pointer Index
	Ip  = (iota * GeneralPurposeRegSize) + SpecialPurposeRegCount
)

func to16(h, l uint8) uint16 {
	return (uint16(h) << ByteSize) | uint16(l)
}

func from16(value uint16) (uint8, uint8) {
	return uint8(value << ByteSize), uint8(value & 0xff)
}

// Type alias is used here and not on bytes or words because there is not a native uint24 type
type addr = uint32

// From a triplet of uint8 (uint24) to uint32 (as address)
func toAddr(h, m, l uint8) addr {
	return (addr(h) << (2 * ByteSize)) | (addr(m) << (1 * ByteSize)) | addr(l)
}

func fromAddr(address addr) (uint8, uint8, uint8) {
	return uint8(address >> (2 * ByteSize)), uint8(address >> (1 * ByteSize)), uint8(address & 0xff)
}