package cpu

import "fmt"

const (
	Nop uint8 = iota
)

func (c *Cpu) Fetch() uint8 {
	return c.nextByte()
}

func (c *Cpu) Execute(opcode uint8) error {

	switch opcode {
	case Nop:
		break

	default:
		return fmt.Errorf("[execution] exception: not legal opcode [%x]", opcode)
	}

	return nil
}
