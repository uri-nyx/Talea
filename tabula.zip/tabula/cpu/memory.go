package cpu

import "fmt"

func (c *Cpu) getRegister8(regIndex int) (error, uint8) {

	if regIndex >= len(c.RegisterFile) {

		err := fmt.Errorf("cannot access register number %d", regIndex)

		return err, 0

	} else {

		return nil, c.RegisterFile[regIndex]
	}
}

func (c *Cpu) getRegister16(regIndex int) (error, uint16) {

	if (regIndex + 1) >= len(c.RegisterFile) {

		err := fmt.Errorf("cannot access register number %d", regIndex)

		return err, 0
	} 

	return nil, to16(c.RegisterFile[regIndex], c.RegisterFile[regIndex + 1])
}

func (c *Cpu) setRegister8(regIndex int, value uint8) error {

	if (regIndex >= len(c.RegisterFile)){

		err := fmt.Errorf("cannot access register number %d", regIndex)

		return err

	}
	
	c.RegisterFile[regIndex] = value
	
	return nil
}

func (c *Cpu) setRegister16(regIndex int, value uint16) error {

	if (regIndex + 1 >= len(c.RegisterFile)){

		err := fmt.Errorf("cannot access register number %d", regIndex)

		return err

	}
	
	h, l := from16(value)

	c.RegisterFile[regIndex] = h
	c.RegisterFile[regIndex + 1] = l
	
	return nil
}

func (c *Cpu) get8(address addr) (error, uint8) {

	if address >= MemorySize {

		err := fmt.Errorf("only %d bytes are addressable, address %d does not exist", MemorySize, address)

		return err, 0

	}

	return nil, c.Memory[address]
}

func (c *Cpu) get16(address addr) (error, uint16) {

	if address + 1 >= MemorySize {

		err := fmt.Errorf("requested word does not exist: only %d bytes are addressable, address %x does not exist", MemorySize, address + 1)

		return err, 0

	}

	return nil, to16(c.Memory[address], c.Memory[address + 1])
}

func (c *Cpu) set8(address addr, value uint8) error {

	if address >= MemorySize {

		err := fmt.Errorf("only %d bytes are addressable, address %x does not exist", MemorySize, address)

		return err

	}

	c.Memory[address] = value
	return nil
}

func (c *Cpu) set16(address addr, value uint16) error {
	
	if address + 1 >= MemorySize {

		err := fmt.Errorf("storing Word: only %d bytes are addressable, address %x does not exist", MemorySize, address + 1)

		return err

	}

	h, l := from16(value)
	c.Memory[address] = h
	c.Memory[address + 1] = l

	return nil
}

func (c *Cpu) getIp() addr {
	return toAddr(c.RegisterFile[Ip], c.RegisterFile[Ip + 1], c.RegisterFile[Ip + 2])
}

func (c *Cpu) GetIp() addr {
	return toAddr(c.RegisterFile[Ip], c.RegisterFile[Ip + 1], c.RegisterFile[Ip + 2])
}

func (c *Cpu) setIp(address addr) {

	//Implement a simple overflow if adress is more than 24 bit
	address = address & 0xffffff

	h, m, l := fromAddr(address)
	c.RegisterFile[Ip] = h
	c.RegisterFile[Ip + 1] = m
	c.RegisterFile[Ip + 2] = l
}

func (c *Cpu) nextByte() uint8 {
	err, b := c.get8(c.getIp())

	if err != nil {
		panic(err)
	}

	c.setIp(c.getIp() + Byte)

	return b
}

func (c *Cpu) nextWord() uint16 {
	err, w := c.get16(c.getIp())

	if err != nil {
		panic(err)
	}
	c.setIp(c.getIp() + Word)

	return w
}