package main

import (
	"fmt"

	"github.com/uri-nyx/tabula/cpu"
	"github.com/uri-nyx/tabula/tty"
	"github.com/uri-nyx/tabula/kb"
	"github.com/uri-nyx/tabula/screen"
)

func main() {
	c := cpu.Cpu{}
	tty := tty.Tty{}
	tty.File = "tty.txt"
	kb := kb.Kb{}
	go kb.Init()
	screen.Screen()

	s := ""
	exit := false


	for !exit {
		fmt.Print("tdb> ")
		fmt.Scanln(&s)

		if s == "q" { exit = true }

		db(s, &c, &tty, &kb)
	}
		

}
