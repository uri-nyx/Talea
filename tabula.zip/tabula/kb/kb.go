// Package kb implements a keyboard interface for Taleä.
package kb

import (
	"github.com/eiannone/keyboard"
)

type Kb struct {
	Event keyboard.KeyEvent
}

func (kb *Kb) Init() {

	keysEvents, err := keyboard.GetKeys(10)
	if err != nil {
		panic(err)
	}
	defer func() {
		_ = keyboard.Close()
	}()

	for {
		event := <-keysEvents
		if event.Err != nil {
			panic(event.Err)
		}
		kb.Event = event
	}
}
