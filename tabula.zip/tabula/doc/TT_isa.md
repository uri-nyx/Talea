# Taleä Tabula Instruction Set Architecture

+ Big Endian

## Clock Speed

+ Up to 50 MHz

## Buses

+ Address bus: 24 bits (16M address space)
+ Data bus: 8 bits (byte addressable)

## Registers

### General purpose

+ Acc: Primary accumulator -> 16 bits
+ Bcc: Secondary accumulator -> 16 bits
+ r0-r5: General registers -> 16 bits

### Special purpose

+ Instruction Pointer -> 24 bits
+ Stack Pointer -> 16 bits
+ Frame Pointer -> 16 bits
+ Memory Bank and Flags -> 8 bits (4 | 4)
+ Chapter Byte -> 8 bits
+ Pagina & Litterae Bytes (High and Low Byte Addresses) -> 16 bits

## Instruction Set

