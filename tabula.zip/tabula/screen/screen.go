// Package screen implements an array based screen for Tabula.
package screen

import (
	"math"

	""
)

func Screen() {
	
	})
}
