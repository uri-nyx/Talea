package main

import (
	"fmt"
	//"os"

	// tea "github.com/charmbracelet/bubbletea"
	"github.com/uri-nyx/tabula/cpu"
	"github.com/uri-nyx/tabula/tty"
	"github.com/uri-nyx/tabula/kb"
)

func db(command string, c *cpu.Cpu, t *tty.Tty, k *kb.Kb) {

	switch command {
	case "dr":
		//Displays the current register values
		fmt.Println("Registers:")
		fmt.Printf("Acc: %x, Bcc: %x\n",
			c.RegisterFile[cpu.Acc],
			c.RegisterFile[cpu.Bcc])

		for i := cpu.R0; i <= cpu.R7; i = i + 2 {
			fmt.Printf("R%x: %x\n", i, c.RegisterFile[i])
		}
	case "s":
		//Steps the CPU one instruction
		fmt.Printf("Ip: %x\n", c.GetIp())
		c.Cycle()

	case "m":
		//Displays the memory contents of the 16 next bytes
		ip := c.GetIp()
		fmt.Printf("At %x: ", ip)

		for i := 0; i < 16; i++ {
			fmt.Printf(" %x ", c.Memory[ip+uint32(i)])
		}
		fmt.Printf("\n")
	case "tty":
		//Prints stub to the teletype
		t.Char('a')
		if err := t.Write(); err != nil {
			panic(err)
		}
	case "kb":
		//Prints status of the keyboard
		fmt.Printf("Key: %x\n", k.Event.Key)
		fmt.Printf("Rune: %q\n", k.Event.Rune)

	}
}
